package com.bidding.BiddingSystem;



import com.bidding.BiddingSystem.Controller.ProductController;
import com.bidding.BiddingSystem.Entity.Product;
import com.bidding.BiddingSystem.Services.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class ProductControllerTest {
    
        @Mock
        private ProductService productService;
    
        @InjectMocks
        private ProductController productController;
    
        @BeforeEach
        public void setup() {
            MockitoAnnotations.openMocks(this);
        }
    
        @Test
        public void testGetAllProducts() {
            // Mock data
            Product product1 = new Product();
            product1.setId(1L);
            product1.setName("Product 1");
    
            Product product2 = new Product();
            product2.setId(2L);
            product2.setName("Product 2");
    
            List<Product> products = Arrays.asList(product1, product2);
    
            // Mock ProductService behavior
            when(productService.getAllProducts()).thenReturn(products);
    
            // Perform GET request to /api/products
            ResponseEntity<List<Product>> response = productController.getAllProducts();
    
            // Verify response
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(products, response.getBody());
    
            // Verify ProductService method invocation
            verify(productService, times(1)).getAllProducts();
        }
    
        @Test
        public void testGetProductById() {
            // Mock data
            Long productId = 1L;
            Product product = new Product();
            product.setId(productId);
            product.setName("Product 1");
    
            // Mock ProductService behavior
            when(productService.getProductById(productId)).thenReturn(product);
    
            // Perform GET request to /api/products/{id}
            ResponseEntity<Product> response = productController.getProductById(productId);
    
            // Verify response
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(product, response.getBody());
    
            // Verify ProductService method invocation
            verify(productService, times(1)).getProductById(productId);
        }
    
        @Test
        public void testCreateProduct() {
            // Mock data
            Product product = new Product();
            product.setName("New Product");
    
            // Mock ProductService behavior
            when(productService.saveProduct(any(Product.class))).thenReturn(product);
    
            // Perform POST request to /api/products
            ResponseEntity<Product> response = productController.createProduct(product);
    
            // Verify response
            assertEquals(HttpStatus.CREATED, response.getStatusCode());
            assertEquals(product, response.getBody());
    
            // Verify ProductService method invocation
            verify(productService, times(1)).saveProduct(any(Product.class));
        }
    
        @Test
        public void testGetProductsByCategory() {
            // Mock data
            Long categoryId = 1L;
            Product product1 = new Product();
            product1.setId(1L);
            product1.setName("Product 1");
    
            Product product2 = new Product();
            product2.setId(2L);
            product2.setName("Product 2");
    
            List<Product> products = Arrays.asList(product1, product2);
    
            // Mock ProductService behavior
            when(productService.getProductsByCategory(categoryId)).thenReturn(products);
    
            // Perform GET request to /api/products/category/{categoryId}
            ResponseEntity<List<Product>> response = productController.getProductsByCategory(categoryId);
    
            // Verify response
            assertEquals(HttpStatus.OK, response.getStatusCode());
            assertEquals(products, response.getBody());
    
            // Verify ProductService method invocation
            verify(productService, times(1)).getProductsByCategory(categoryId);
        }
    
        @Test
        public void testDeleteProduct() {
            // Mock data
            Long productId = 1L;
    
            // Perform DELETE request to /api/products/{id}
            ResponseEntity<Void> response = productController.deleteProduct(productId);
    
            // Verify response
            assertEquals(HttpStatus.NO_CONTENT, response.getStatusCode());
    
            // Verify ProductService method invocation
            verify(productService, times(1)).deleteProduct(productId);
        }
    }
    