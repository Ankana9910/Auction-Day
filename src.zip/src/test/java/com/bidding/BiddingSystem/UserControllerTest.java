package com.bidding.BiddingSystem;




import com.bidding.BiddingSystem.Controller.UserController;
import com.bidding.BiddingSystem.Entity.User;
import com.bidding.BiddingSystem.Services.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.List;

public class UserControllerTest {

    @InjectMocks
    private UserController userController;

    @Mock
    private UserService userService;

    @Mock
    private KafkaTemplate<String, User> kafkaTemplate;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testCreateOrUpdateUser_Success() {
        // Mock data
        User user = new User();
        user.setId(1L);
        user.setUsername("testuser");
        user.setUserNo("user123");
        user.setEmail("testuser@example.com");

        // Mock UserService behavior
        when(userService.createOrUpdateUser(any(User.class))).thenReturn(user);

        // Perform POST request to /api/users
        ResponseEntity<User> response = userController.createOrUpdateUser(user);

        // Verify response
        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(user, response.getBody());

        // Verify UserService method invocation
        verify(userService, times(1)).createOrUpdateUser(any(User.class));

        // Verify KafkaTemplate method invocation
        verify(kafkaTemplate, times(1)).send(eq("user"), eq(String.valueOf(user.getId())), eq(user));
    }

    @Test
    public void testGetAllUsers() {
        // Mock data
        User user1 = new User();
        user1.setId(1L);
        user1.setUsername("user1");
        user1.setUserNo("user123");
        user1.setEmail("user1@example.com");

        User user2 = new User();
        user2.setId(2L);
        user2.setUsername("user2");
        user2.setUserNo("user456");
        user2.setEmail("user2@example.com");

        List<User> userList = Arrays.asList(user1, user2);

        // Mock UserService behavior
        when(userService.getAllUsers()).thenReturn(userList);

        // Perform GET request to /api/users
        ResponseEntity<List<User>> response = userController.getAllUsers();

        // Verify response
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(userList, response.getBody());

        // Verify UserService method invocation
        verify(userService, times(1)).getAllUsers();
    }

    // Additional test cases for update and delete methods can be added similarly
}

