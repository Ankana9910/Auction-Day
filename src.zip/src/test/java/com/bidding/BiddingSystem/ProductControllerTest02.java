package com.bidding.BiddingSystem;


import com.bidding.BiddingSystem.Controller.ProductCatController;
import com.bidding.BiddingSystem.Controller.ProductController;
import com.bidding.BiddingSystem.Entity.Product;
import com.bidding.BiddingSystem.Entity.ProductCategory;
import com.bidding.BiddingSystem.Services.ProductCategoryService;
import com.bidding.BiddingSystem.Services.ProductService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class ProductControllerTest02 {

    @Mock
    private ProductService productService;

    @Mock
    private ProductCategoryService productCategoryService;

    @InjectMocks
    private ProductController productController;

    @InjectMocks
    private ProductCatController productCatController;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddProductWithCategory() {
        // Mock data for ProductCategory
        ProductCategory category = new ProductCategory();
        category.setId(1L);
        category.setName("Electronics");

        // Mock behavior for ProductCategoryService
        when(productCategoryService.createProductCategory(any(ProductCategory.class))).thenReturn(category);

        // Mock data for Product
        Product product = new Product();
        product.setId(1L);
        product.setName("Smartphone");
        product.setBasePrice(new BigDecimal("500.00"));
        product.setCategory(category); // Set category name

        // Mock behavior for ProductService
        when(productService.saveProduct(any(Product.class))).thenReturn(product);

        // Perform POST request to create product category
        ProductCategory createdCategory = new ProductCategory();
        createdCategory.setName("Electronics");

        ResponseEntity<ProductCategory> categoryResponse = productCatController.createProductCategory(createdCategory);

        // Verify response for category creation
        assertEquals(HttpStatus.CREATED, categoryResponse.getStatusCode());
        assertEquals(category.getName(), categoryResponse.getBody().getName());

        // Perform POST request to create product with category
        ResponseEntity<Product> productResponse = productController.createProduct(product);

        // Verify response for product creation
        assertEquals(HttpStatus.CREATED, productResponse.getStatusCode());
        assertEquals(product.getName(), productResponse.getBody().getName());
        assertEquals(product.getBasePrice(), productResponse.getBody().getBasePrice());
        assertEquals(product.getCategory(), productResponse.getBody().getCategory());

        // Verify ProductService method invocation
        verify(productService, times(1)).saveProduct(any(Product.class));

        // Verify ProductCategoryService method invocation
        verify(productCategoryService, times(1)).createProductCategory(any(ProductCategory.class));
    }
}
