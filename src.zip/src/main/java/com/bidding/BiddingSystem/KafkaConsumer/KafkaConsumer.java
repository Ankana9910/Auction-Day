package com.bidding.BiddingSystem.KafkaConsumer;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

import com.bidding.BiddingSystem.Entity.User;

@Component
public class KafkaConsumer {
    private final ConcurrentMap<String, User> userCache = new ConcurrentHashMap<>();

    @KafkaListener(topics = "user", groupId = "group_id")
    public void consume(User user) {
        // Update local cache with received user data
        userCache.put(user.getId().toString(), user);
    }

    public boolean userExists(String userId) {
        return userCache.containsKey(userId);
    }

}