package com.bidding.BiddingSystem.Repository;


import org.apache.kafka.common.metrics.stats.Histogram.BinScheme;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bidding.BiddingSystem.Entity.Bidding;
import com.bidding.BiddingSystem.Entity.Product;
//import com.bidding.BiddingSystem.Entity.TimeSlot;
import com.bidding.BiddingSystem.Entity.User;
import java.math.BigDecimal;
import java.util.List;

@Repository
public interface BiddingRepository extends JpaRepository<Bidding, Long> {
    List<Bidding> findByProduct(Product product);
    //Bidding findByProductAmt(Bidding bidAmount);

    Bidding findById(long id); // List<Bidding> findByBiddingTimeSlot(TimeSlot biddingTimeSlot);
    Bidding findByUserAndProduct(User user, Product product);

   
    
}
