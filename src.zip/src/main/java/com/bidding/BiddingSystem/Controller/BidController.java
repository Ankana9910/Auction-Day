package com.bidding.BiddingSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.bidding.BiddingSystem.DTO.BidDTO;
import com.bidding.BiddingSystem.Entity.Bidding;
import com.bidding.BiddingSystem.Entity.Product;
import com.bidding.BiddingSystem.Entity.User;
import com.bidding.BiddingSystem.KafkaConsumer.KafkaConsumer;
import com.bidding.BiddingSystem.KafkaProducer.KafkaProducer;
import com.bidding.BiddingSystem.Services.BiddingService;

import com.bidding.BiddingSystem.Services.ProductService;
import com.bidding.BiddingSystem.Services.UserService;

//import jakarta.mail.MessagingException;

import com.bidding.BiddingSystem.Services.EmailService;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/bids")
public class BidController {

    
    private  BiddingService bidService;

    @Autowired
    private ProductService productService;
    private KafkaProducer kafkaProducer;
    private KafkaConsumer kafkaConsumer;
    @Autowired
    private EmailService emailService;

    @Autowired
    private BiddingService biddingService;
    @Autowired
    private UserService userService;
  

    @Autowired
    public BidController(BiddingService biddingService,KafkaProducer kafkaProducer) {
        this.biddingService = biddingService;
        this.kafkaProducer = kafkaProducer;

    }
    

    @PostMapping("/place")
    public ResponseEntity<?> placeBid(@RequestBody BidDTO bidRequest) {
        try {
           
          
            Product product = productService.getProductById(bidRequest.getProductId());
            User user = userService.getUserById(bidRequest.getUserId());
          
            if (product == null) {
                return ResponseEntity.badRequest().body("Product not found");
            }
            

            // Check for duplicate bid by user for the product
              biddingService.checkDuplicateBid(userService.getUserById(bidRequest.getUserId()), product);
    
            // Validate bid amount against selling price
            if (bidRequest.getBidAmount().compareTo(product.getBasePrice()) < 0) {
                return ResponseEntity.badRequest().body("Bid amount cannot be less than the selling price!");
            }
    
            // Validate bid time against product listing start and end times
            LocalDateTime bidTime = bidRequest.getBidTime();
            LocalDateTime startTime = product.getStartTime();
            LocalDateTime endTime = product.getEndTime();
    
            if (bidTime.isBefore(startTime) || bidTime.isAfter(endTime)) {
                return ResponseEntity.badRequest().body("Bid time must be between product listing start time and end time!");
            }
                
            // Place the bid
            Bidding bid = new Bidding();
           
            bid.setProduct(product);
            bid.setUser(user);
            bid.setBidAmount(bidRequest.getBidAmount());
            //bid.setBidTime(LocalDateTime.now());
    
            Bidding placedBid = biddingService.placeBid(bid);
    
            return ResponseEntity.status(HttpStatus.CREATED).body(placedBid);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error placing bid: " + e.getMessage());
        }
    }
    
    @PutMapping("/{bidId}")
    public ResponseEntity<Bidding> updateBid(@PathVariable Long bidId, @RequestBody Bidding updatedBid) {
        // Fetch the existing bid by bidId
        Bidding existingBid = bidService.getBidById(bidId);

        if (existingBid == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        // Update the bid with new details
        existingBid.setBidAmount(updatedBid.getBidAmount());
        //existingBid.setBidTime(updatedBid.getBidTime());

        // Save the updated bid
        Bidding savedBid = bidService.placeBid(existingBid); 

        return new ResponseEntity<>(savedBid, HttpStatus.OK);
    }

    // Endpoint to determine the winner after each bidding slot for a specific product
    @GetMapping("/product/{productId}/winner")
    public ResponseEntity<String> determineWinnerForProduct(@PathVariable Long productId) {
        Product product = productService.getProductById(productId);
        if (product == null) {
            return ResponseEntity.notFound().build();
        }

        Bidding winningBid = biddingService.determineWinnerForProduct(product);
        if (winningBid == null) {
            return ResponseEntity.noContent().build(); // No bids found
        }
       
     return ResponseEntity.ok(winningBid.getUser().getUsername()+" "+"has won the Auction for product"+" "+winningBid.getProduct().getName()+" "+"@"+""+winningBid.getBidAmount());

        
        
    }
}




/*// Construct email message
        String subject = "Auction Winner Notification";
        String body = String.format("Congratulations! You have won the auction for %s with a bid of %s.",
                winningBid.getProduct().getName(), winningBid.getBidAmount());

        // Send email to winner
        try {
            emailService.sendEmail(winningBid.getUser().getEmail(), subject, body);
            return ResponseEntity.ok("Winner notified by email: " + body);
        } catch (MessagingException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error sending email: " + e.getMessage());
        }*/
        