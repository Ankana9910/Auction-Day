package com.bidding.BiddingSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.bidding.BiddingSystem.Entity.Product;
import com.bidding.BiddingSystem.Services.ProductService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductService productService;
    private static final Logger logger = LoggerFactory.getLogger(ProductController.class);

    @Autowired
    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        try {
            List<Product> products = productService.getAllProducts();
            logger.info("Retrieved {} products successfully", products.size());
            return new ResponseEntity<>(products, HttpStatus.OK);
        } catch (Exception e) {
            logger.error("Error occurred while fetching products: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }

      
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {
        try{
        Product product = productService.getProductById(id);
        logger.info("Retrieved products successfully");
        return new ResponseEntity<>(product, HttpStatus.OK);
        }
        catch(Exception e)
        {
            logger.error("Error occurred while fetching products: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);

        }
    }

    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        try{
        Product createdProduct = productService.saveProduct(product);
        logger.info("Created products successfully");
        return new ResponseEntity<>(createdProduct, HttpStatus.CREATED);
        }
        catch (Exception e)
        {
            logger.error("Error occurred while creating products", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);

        }
    }
  
    @GetMapping("/category/{categoryId}")
    public ResponseEntity<List<Product>> getProductsByCategory(@PathVariable Long categoryId) {
        try{
        List<Product> products = productService.getProductsByCategory(categoryId);
        logger.info("Displayed products successfully");
        return new ResponseEntity<>(products, HttpStatus.OK);
        }
        catch(Exception e)
        {
            logger.error("Error occurred while displaying products", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);

        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable Long id) {
        productService.deleteProduct(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }


    
}
