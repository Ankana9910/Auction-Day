package com.bidding.BiddingSystem.Controller;


import com.bidding.BiddingSystem.Entity.User;
import com.bidding.BiddingSystem.Services.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;
@Autowired
    private KafkaTemplate<String, User> kafkaTemplate;
    private static final Logger logger = LoggerFactory.getLogger(UserController.class);


    @PostMapping
    public ResponseEntity<User> createOrUpdateUser(@RequestBody User user) {
        

        try {
            User createdOrUpdatedUser = userService.createOrUpdateUser(user);
        kafkaTemplate.send("user", user.getId().toString(), user);
            logger.info("Sent user data to Kafka: {}", user);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdOrUpdatedUser);
        } catch (Exception e) {
        logger.error("Failed to send user data to Kafka", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
  

    }

    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        try{
        List<User> users = userService.getAllUsers();
        logger.info("User Data displayed: {}");
        return ResponseEntity.ok(users);
        }
        catch(Exception e)
        {
            logger.error("Unable to fetch Users", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();

        }
        
    }

    @PutMapping("/{userId}")
    public ResponseEntity<User> updateuser(@PathVariable Long userId, @RequestBody User updateduser) {

        try{
        User user = userService.updateUser(userId, updateduser);
        logger.info("User Data updated: {}");
                    return ResponseEntity.ok(user);
        }
        catch(Exception e){
            logger.error("Unable to fetch User with user ID", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();

        }
            }

    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> deleteuser(@PathVariable Long userId) {
        try{
        userService.deleteUser(userId);
        logger.info("User Deleted: {}");
        return ResponseEntity.noContent().build();
        
        }
        catch(Exception e)
        {
            logger.error("Unable to fetch User with user ID to delete", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
    
