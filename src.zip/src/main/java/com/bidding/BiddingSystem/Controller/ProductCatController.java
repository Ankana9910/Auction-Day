package com.bidding.BiddingSystem.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.bidding.BiddingSystem.Entity.ProductCategory;
import com.bidding.BiddingSystem.Services.ProductCategoryService;
import java.util.List;

@RestController
@RequestMapping("/api/product-categories")
public class ProductCatController {

    @Autowired
    private ProductCategoryService productCategoryService;

    @PostMapping
    public ResponseEntity<ProductCategory> createProductCategory(@RequestBody ProductCategory productCategory) {
        ProductCategory createdCategory = productCategoryService.createProductCategory(productCategory);
        return new ResponseEntity<>(createdCategory, HttpStatus.CREATED);
    }
    @GetMapping
    public ResponseEntity<List<ProductCategory>> getAllUsers() {
        List<ProductCategory> prod = productCategoryService.getAllCategory();
        return ResponseEntity.ok(prod);
    }
    

    
}