package com.bidding.BiddingSystem.Services;

//import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bidding.BiddingSystem.Entity.User;
import com.bidding.BiddingSystem.Repository.UserRepository;

import jakarta.transaction.Transactional;

//import java.util.List;
import java.util.List;

@Service
@Transactional
public class UserService {

    @Autowired
    private UserRepository userRepository;
  

    

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    

    public User createOrUpdateUser(User user) {
        return userRepository.save(user);
    }
     
    
    
    public User updateUser(Long userId, User updateduser) {
        updateduser.setId(userId);
        return userRepository.save(updateduser);
    }

    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }
   
    public User getUserById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }


   
}
