package com.bidding.BiddingSystem.Services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.bidding.BiddingSystem.Entity.Bidding;
import com.bidding.BiddingSystem.Entity.Product;
import com.bidding.BiddingSystem.Entity.User;
import com.bidding.BiddingSystem.Repository.BiddingRepository;
import com.bidding.BiddingSystem.Repository.UserRepository;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;


@Service
@Transactional
public class BiddingService {

    @Autowired
    private BiddingRepository bidRepository;

    @Autowired
    private UserService userService; 
    private UserRepository userRepository;
    @Autowired
    private ProductService productService;
    
    private BiddingService bidService;
    
    
   @Autowired
   public BiddingService(BiddingRepository biddingRepository, ProductService productService) {
       
       this.bidRepository = biddingRepository;
       this.productService = productService;
   }

    public List<Bidding> getBidsByProduct(Product product) {
        return bidRepository.findByProduct(product);
    }

    

    public Bidding placeBid(Bidding bid) {
    
    // Validate bid amount against selling price of the product
    Product product = bid.getProduct();
    BigDecimal bidAmount = bid.getBidAmount();

    if (product == null) {
        throw new IllegalArgumentException("Product cannot be null");
    }

    if (bidAmount == null || bidAmount.compareTo(BigDecimal.ZERO) <= 0) {
        throw new IllegalArgumentException("Invalid bid amount");
    }

    if (bidAmount.compareTo(product.getBasePrice()) < 0) {
        throw new IllegalArgumentException("Bid amount cannot be less than the selling price!");
    }

      //Check Duplicate Bids
       checkDuplicateBid(bid.getUser(), product);
        
        bid.setUser(userService.getUserById(bid.getUser().getId()));

   
    return bidRepository.save(bid);
}

public void checkDuplicateBid(User user, Product product) {
    Bidding existingBid = bidRepository.findByUserAndProduct(user, product);
    if (existingBid != null) {
        throw new IllegalArgumentException("User has already placed a bid for this product");
    }
}
    
       
    public Bidding getBidById(Long bidId) {
        return bidRepository.findById(bidId).orElse(null);
    }

    public List<Bidding> getAllBidsForProduct(Product product) {
        // Assuming you have a method in BiddingRepository to find all bids by product
        return bidRepository.findByProduct(product);
    }

    public Bidding determineWinnerForProduct(Product product) {
        List<Bidding> bids = getAllBidsForProduct(product);
        if (bids == null || bids.isEmpty()) {
            return null; // No bids for the product
        }

        // Find the bid with the highest amount
        Bidding winningBid = bids.stream()
                .max(Comparator.comparing(Bidding::getBidAmount))
                .orElse(null);

        return winningBid;
    }






















    /*public Bidding getAllBidsForProductbyAmount(Bidding bidAmount) {
        // TODO Auto-generated method stub
        return bidRepository.findByProductAmt(bidAmount.getBidAmount());
        */

    
    /*private void sendWinnerEmailNotification(Bidding winningBid) {
        User winner = winningBid.getUser();
        if (winner != null) {
            String recipientEmail = winner.getEmail(); // Ensure getEmail() returns the email address
            String productName = winningBid.getProduct().getName();

            if (recipientEmail != null) {
                emailService.sendWinnerNotification(recipientEmail, productName);
            } else {
                // Handle case where recipientEmail is null
                System.out.println("Recipient email address is null for winner: " + winner.getUsername());
            }
        } else {
            // Handle case where winner is null
            System.out.println("Winner is null for bid id: " + winningBid.getId());
        }
    }*/
}