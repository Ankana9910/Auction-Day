package com.bidding.BiddingSystem.Services;



//import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.bidding.BiddingSystem.Entity.ProductCategory;
import com.bidding.BiddingSystem.Repository.ProductCatRepository;

import jakarta.transaction.Transactional;

import java.util.List;

@Service
@Transactional
public class ProductCategoryService {

    @Autowired
    private ProductCatRepository productCategoryRepository;

    public ProductCategory createProductCategory(ProductCategory productCategory) {
        return productCategoryRepository.save(productCategory);
    }

    public List<ProductCategory> getAllCategory() {
        return productCategoryRepository.findAll();
    }
    

    
}
